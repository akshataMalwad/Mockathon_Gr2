var app = angular.module('myApp', ["ngRoute", "ngStorage"]);
app.config(function ($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "views/login.html",
            controller: "loginController"
        })
        .when("/register", {
            templateUrl: "views/register.html",
            controller: "registerController"
        })
        .when("/emiCalc", {
            templateUrl: "views/emiCalc.html",
            controller: "emiController"
        })
        .when("/apply", {
            templateUrl: "views/apply.html",
            controller: "applyController"
        })
        .when("/applicationForm", {
            templateUrl: "views/applicationForm.html",
            controller: "applicationController"
        })
        .when("/userRequest", {
            templateUrl: "views/userRequest.html",
            controller: "userReqController"
        })
        .when("/logout", {
            template: "<p>You Have Successfully log out...",
            controller: "logoutController"
        })
        .when("/invalidUser", {
            template: "<p>Restricted access...</p>",
            controller: "invalidUserController"
        })
});