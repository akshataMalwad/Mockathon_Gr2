app.controller('userReqController', function($scope, $http, $location, $rootScope, $localStorage) {
 $rootScope.userData = $localStorage.userData;
 if( $rootScope.userData && $rootScope.userData.role !== 'admin') {
     $location.path('/invalidUser');
 } else if($rootScope.userData == "") {
        $location.path('/');
 } 
$scope.regReq = {};
$scope.loanReq = {};
$http.get("http://10.117.189.142:8080/regPendingApprovalList")
    .then(function(response) {
        $scope.regReq = response.data;
    });

    $http.get("http://10.117.189.142:8080/loanPendingApprovalList")
    .then(function(response) {
        $scope.loanReq = response.data;
    });

var status='';
var findUserId = function (aadhar, status){
    var userIndex = $scope.regReq.findIndex(function(index){
        return index.aadharNumber === aadhar;
    });
    $scope.regReq.splice(userIndex, 1);
    $http.get("http://10.117.189.142:8080/regApproval?aadharNumber="+aadhar+"&status="+status)
    .then(function(response) {
        if(response.status===200){
            alert('Your request is completed!');
        }
    });
}

var findLoanId = function (aadhar, status){
    $scope.loanReq.splice($scope.loanReq.findIndex(function(index){
        return index.aadharNumber === aadhar;
    }), 1);
    $http.get("http://10.117.189.142:8080/loanApproval?aadharNumber="+aadhar+"&status="+status)
    .then(function(response) {
        if(response.status===200){
            alert('Your request is completed!');
        }
    });
}
$scope.onRegApprove = function(aadhar){
    if(aadhar) {
        status = 'approved';
        findUserId(aadhar, status);
    }
}

$scope.onRegReject = function(aadhar){
    if(aadhar) {
        status = 'rejected';
        findUserId(aadhar, status);
    }
}
$scope.onLoanApprove = function(aadhar){
    if(aadhar) {
          status = 'approved';
        findLoanId(aadhar, status);
    }
}

$scope.onLoanReject = function(CustId){
    if(aadhar) {
         status = 'rejected';
        findLoanId(aadhar, status);
    }
}
});