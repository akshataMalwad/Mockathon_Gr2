app.controller('loginController', function ($scope, $http, $location, $rootScope, $localStorage) {
    var data = { username: "", password: "" };

    $rootScope.userData;
    $scope.onSubmit = function () {
        $http.post('http://10.117.189.142:8080/login',
            {
                "userName": $scope.username,
                "password": $scope.password,
                "role": $scope.role
            }).then(function (response) {
                if (response.status === 200) {

                    $localStorage.userData = response.data;
                    $rootScope.userData = $localStorage.userData;

                    if (response.data.role == 'admin') {
                        $location.path('/userRequest');
                    } else {
                        $location.path('/apply');
                    }
                } else {
                    $scope.alertMsg = 'Invalid login details';
                }
            }, function (err) {
                $scope.alertMsg = 'Invalid login details';
            });
    }
});