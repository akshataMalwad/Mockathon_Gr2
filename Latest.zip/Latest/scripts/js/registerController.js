app.controller('registerController', function($scope, $http, $location) {

    $scope.onRegister= function(){
        debugger;
        $http.post('http://10.117.189.142:8080/register', {
            "userName": $scope.username,
            "fullName" : $scope.name,
            "email" : $scope.email, 
            "password" : $scope.password, 
            "aadharNumber" : $scope.aadhar, 
            "contactNumber" : $scope.contact
        }).then(function (response){
        if(response.status=== 201) {
           alert("Your registration request is submitted, Pending for approval.");
           $location.path('/logout');
        } else { 
           alert('Your registration failed');
        }
    });
    }
});
