app.controller('applicationController',function($scope, $localStorage, $rootScope, $location, $http) {
    $rootScope.userData = $localStorage.userData;
    $scope.userData = $localStorage.userData;
    if($rootScope.userData == "") {
        $location.path('/');
    }
    $scope.onSubmit = function() {
        $http.post('http://10.117.189.142:8080/applyLoan',{
            "aadharNumber": $scope.userData.aadharNumber,
            "loanAmount": $scope.amount,
            "tenure" : $scope.tenure
        }).then(function (response) {
             if(response.status===201) {
                 $localStorage.userDataNew = response.data;
                 $location.path('/apply');
             } else { 
                 $scope.alertMsg = 'Invalid login details';   
             }
     }, function(err) {
          $scope.alertMsg = 'loan request rejected';
    });
}
});