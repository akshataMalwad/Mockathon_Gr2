app.controller('logoutController',function($scope,$rootScope,$localStorage,$location) {
    $localStorage.userData = '';
    $localStorage.userDataNew = '';
    $rootScope.userData = '';
    $location.path('/');
})