app.controller('applyController', function ($scope, $rootScope, $localStorage, $location, $http) {
    $rootScope.userData = $localStorage.userData;

    if ($rootScope.userData == "") {
        $location.path('/');
    }

     $rootScope.userData = $localStorage.userData?$localStorage.userData:'';
    $scope.loanReq=[];
    $scope.isLoanApplied = false;
    if ($localStorage.userData && $localStorage.userData.loanStatus==='pending') {
        $scope.isLoanApplied = $localStorage.userData.loanId ? true : false;
        $scope.loanReq.push({
        'loanId': $localStorage.userData.loanId, 
        'loanStatus': $localStorage.userData.loanStatus, 
        'loanAmount': $localStorage.userData.loanAmount, 
        'tenure': $localStorage.userData.tenure
    });
    } else {
        $http.post('http://10.117.189.142:8080/loanDetails',{
            "aadharNumber": $scope.userData.aadharNumber,
        }).then(function (response) {
             if(response.status===200) {
                 $scope.isLoanApplied = true;
                 $localStorage.userDataNew = response.data;
                  $scope.loanReq.push({
                   'loanId': $localStorage.userDataNew.loanId, 
                    'loanStatus': $localStorage.userDataNew.loanStatus, 
                  'loanAmount': $localStorage.userDataNew.loanAmount, 
                   'tenure': $localStorage.userDataNew.tenure
         });
             }
     });
    }
});
