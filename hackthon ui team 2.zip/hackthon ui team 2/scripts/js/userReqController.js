app.controller('userReqController',function($scope){

});