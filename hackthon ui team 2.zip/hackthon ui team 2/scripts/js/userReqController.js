app.controller('userReqController', function($scope, $http, $location, $rootScope, $localStorage) {
 $rootScope.userData = $localStorage.userData;

 if($rootScope.userData.role !== 'admin') {
     $location.path('/invalidUser');
 } else if($rootScope.userData == "") {
        $location.path('/');
   } 

/*$http.get('http://10.117.189.142:8080/regPendingApprovalList').then(function (response){
    console.log(JSON.stringify(response.data))
});*/

$http.get("http://10.117.189.142:8080/regPendingApprovalList")
    .then(function(response) {
        console.log(response.data);
        $scope.regReq = response.data;
    });

    $http.get("http://10.117.189.142:8080/loanPendingApprovalList")
    .then(function(response) {
        console.log(response.data);
        $scope.loanReq = response.data;
    });

$scope.noRegRecords=false;
$scope.noLoanRecords=false;
var findUserId = function (aadhar){
    $scope.regReq.splice($scope.regReq.findIndex(function(index){
        return index.aadhar === aadhar;
    }), 1);
    if ($scope.regReq.length===0) {
        $scope.noRegRecords=true;
    }
}

var findLoanId = function (CustId){
    $scope.loanReq.splice($scope.loanReq.findIndex(function(index){
        return index.CustId === CustId;
    }), 1);
    if ($scope.loanReq.length===0) {
        $scope.noLoanRecords=true;
    }
}
$scope.onRegApprove = function(aadhar){
    if(aadhar) {
        findUserId(aadhar);
    }
}

$scope.onRegReject = function(aadhar){
    if(aadhar) {
        findUserId(aadhar);
    }
}
$scope.onLoanApprove = function(CustId){
    if(CustId) {
        findLoanId(CustId);
    }
}

$scope.onLoanReject = function(CustId){
    if(CustId) {
        findLoanId(CustId);
    }
}
});