app.controller('userReqController', function($scope, $http, $location, $rootScope, $localStorage) {
 $rootScope.userData = $localStorage.userData;

 if($rootScope.userData.role !== 'admin') {
     $location.path('/invalidUser');
 } else if($rootScope.userData == "") {
        $location.path('/');
   } 

$scope.loanReq =[{
    CustId:1,
    acntNo:111,
    loanAmnt:10000,
    tenure:11
},{
    CustId:2,
    acntNo:222,
    loanAmnt:20000,
    tenure:12
},{
    CustId:3,
    acntNo:333,
    loanAmnt:30000,
    tenure:13
}];
$scope.regReq =[{
    userName:'aaa',
    fullName:'aaa xyz',
    email:'aaa@sdf.com',
    AadharNumber:12342342341,
    contactNumber:627534753
},{
    userName:'bbb',
    fullName:'bbb xyz',
    email:'bbb@sdf.com',
    AadharNumber:5234542341,
    contactNumber:8888888753
},{
   userName:'ccc',
    fullName:'ccc xyz',
    email:'ccc@sdf.com',
    AadharNumber: 99992342341,
    contactNumber:6267576765
}];

$scope.noRegRecords=false;
$scope.noLoanRecords=false;
var findUserId = function (aadhar){
    $scope.regReq.splice($scope.regReq.findIndex(function(index){
        return index.aadhar === aadhar;
    }), 1);
    if ($scope.regReq.length===0) {
        $scope.noRegRecords=true;
    }
}

var findLoanId = function (CustId){
    $scope.loanReq.splice($scope.loanReq.findIndex(function(index){
        return index.CustId === CustId;
    }), 1);
    if ($scope.loanReq.length===0) {
        $scope.noLoanRecords=true;
    }
}
$scope.onRegApprove = function(aadhar){
    if(aadhar) {
        findUserId(aadhar);
    }
}

$scope.onRegReject = function(aadhar){
    if(aadhar) {
        findUserId(aadhar);
    }
}
$scope.onLoanApprove = function(CustId){
    if(CustId) {
        findLoanId(CustId);
    }
}

$scope.onLoanReject = function(CustId){
    if(CustId) {
        findLoanId(CustId);
    }
}
});