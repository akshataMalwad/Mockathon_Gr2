app.controller('applyController',function($scope,$rootScope,$localStorage,$location) {
   $rootScope.userData = $localStorage.userData;

   if($rootScope.userData == "") {
        $location.path('/');
   }
})