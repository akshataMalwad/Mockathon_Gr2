app.controller('logoutController',function($scope,$rootScope,$localStorage,$location) {
    $localStorage.userData = '';
    $rootScope.userData = '';
    $location.path('/');
})