app.controller('loanReqController',function($scope){
 $scope.loanReq =[{
    CustId:1,
    acntNo:111,
    loanAmnt:10000,
    tenure:11
},{
    CustId:2,
    acntNo:222,
    loanAmnt:20000,
    tenure:12
},{
    CustId:3,
    acntNo:333,
    loanAmnt:30000,
    tenure:13
}];

});