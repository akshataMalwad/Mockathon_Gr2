app.controller('loanReqController',function($scope){

});