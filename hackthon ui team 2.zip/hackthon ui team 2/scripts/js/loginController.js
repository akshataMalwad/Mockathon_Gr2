app.controller('loginController', function($scope, $http, $location) {
    var data= {username: "", password: ""};
    // $scope.reset = function() {
    //     $scope.user = angular.copy($scope.data);
    // };
    
    $scope.onSubmit= function(){
        debugger;
        $http.post('http://10.117.189.142:8080/login',  //134
        {
             "username": $scope.username,
             "password" : $scope.password,
             "role" : $scope.role
        }).then(function (response){
        if(response.status===200) {
           alert("success");
           $location.path('/apply');
        } else { 
           alert('invalid username and password');
        }
    });
    }
});