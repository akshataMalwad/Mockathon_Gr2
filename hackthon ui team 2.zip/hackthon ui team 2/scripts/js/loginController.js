app.controller('loginController', function($scope, $http) {
    $scope.master = {username: "", password: ""};
    $scope.reset = function() {
        $scope.user = angular.copy($scope.master);
    };

    function successCallback(response){
alert("success");
    }
    function errorCallback(error){
alert("error");
    }
    $scope.onSubmit= function(){
        $http.post('https://jsonplaceholder.typicode.com/posts/1', data).then(successCallback, errorCallback);
    }
});