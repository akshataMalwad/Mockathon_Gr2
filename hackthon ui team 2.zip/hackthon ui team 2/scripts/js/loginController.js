app.controller('loginController', function($scope, $http, $location, $rootScope, $localStorage) {
    var data= {username: "", password: ""};
    // $scope.reset = function() {
    //     $scope.user = angular.copy($scope.data);
    // };
    $rootScope.userData;
    $scope.onSubmit= function(){
        debugger;
        $http.post('http://10.117.189.142:8080/login',  //134
        {
             "userName": $scope.username,
             "password" : $scope.password,
             "role" : $scope.role
        }).then(function (response){
        if(response.status===200) {

        $localStorage.userData = response.data;
        $rootScope.userData = $localStorage.userData;
        
           alert("success");
           //$rootScope.userData = response.data;
           console.log(response.data)
           if(response.data.role == 'admin') {
            $location.path('/userRequest');
           } else {
            $location.path('/apply');
           }
        } else { 
           $scope.alertMsg = 'Invalid login details';   
        }
    }, function(err) {
        $scope.alertMsg = 'Invalid login details';
    });
    }
});