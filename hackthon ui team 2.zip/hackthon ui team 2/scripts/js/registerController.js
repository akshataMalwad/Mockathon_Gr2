app.controller('registerController', function($scope) {
    $scope.master = {username: "", password: ""};
    $scope.reset = function() {
        $scope.user = angular.copy($scope.master);
    };
    $scope.reset();
});