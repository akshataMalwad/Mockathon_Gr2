app.controller('invalidUserController', function($scope, $http, $location, $rootScope, $localStorage, $timeout) {
   $rootScope.userData = $localStorage.userData;
   if($rootScope.userData.role !== 'admin') {
    $timeout( function(){
         $location.path('/apply');
    }, 5000 )
    
   } else if($rootScope.userData == "") {
        $location.path('/');
   } 
});