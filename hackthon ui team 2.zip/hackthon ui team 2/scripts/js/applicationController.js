app.controller('applicationController',function($scope,$localStorage,$rootScope) {
    $rootScope.userData = $localStorage.userData;

    if($rootScope.userData == "") {
        $location.path('/');
   }
});