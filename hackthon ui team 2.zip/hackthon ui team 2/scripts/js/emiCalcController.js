app.controller('emiController', function($scope) {
    
    $scope.principal = $scope.amount;
    $scope.tenure = $scope.tenure;
    $scope.years = $scope.tenure / 12;
    
    $scope.calculateEMI = function() {
        //alert($scope.principal);alert($scope.amount);
        $scope.emi = (($scope.amount * 8.35 * ($scope.tenure/12)) / 100) + $scope.amount / $scope.tenure;
        
        $scope.totalAmount = $scope.emi * $scope.tenure;
    }
})