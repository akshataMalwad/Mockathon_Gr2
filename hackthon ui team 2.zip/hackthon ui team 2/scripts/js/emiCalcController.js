app.controller('emiController', function($scope) {
    
    $scope.principal = $scope.amount;
    $scope.tenure = $scope.tenure;
    $scope.years = $scope.tenure / 12;
    
    $scope.calculateEMI = function() {
        /*alert($scope.principal);*/alert($scope.amount);
       $scope.emi = (($scope.amount * 8.35 * ($scope.tenure/12)) / 100) + $scope.amount / $scope.tenure;

        //$scope.emi = ($scope.amount ((1+(8.35/100)) / ($scope.tenure/12))) / $scope.tenure;
        
        $scope.totalAmount = $scope.emi * $scope.tenure;
    }
});


app.directive('numberMask', function() {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9.]/g, '');

            if (digits.split('.').length > 2) {
              digits = digits.substring(0, digits.length - 1);
            }

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseFloat(digits);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});