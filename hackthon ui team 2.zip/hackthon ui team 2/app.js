var app = angular.module('myApp', ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "views/login.html",
        controller : "loginController"
    })
    .when("/register", {
        templateUrl : "views/register.html",
         controller : "registerController"
    })
    .when("/emiCalc", {
        templateUrl : "views/emiCalc.html",
         controller : "emiController"
    })
    .when("/apply", {
        templateUrl : "views/apply.html",
    })
    .when("/applicationForm", {
        templateUrl : "views/applicationForm.html",
        controller : "applicationController"
    })
    .when("/loanRequest", {
        templateUrl : "views/loanRequest.html",
        controller : "loanReqController"
    })
    .when("/userRequest", {
        templateUrl : "views/userRequest.html",
        controller : "userReqController"
    })
});